# TOYINMDBOT

WhatsApp Multi-Device bot using Node.js and Baileys.

## Included in this starter
- Pairing-code API (`POST /api/pair`)
- Saved Baileys authentication state
- `.menu`, `.ping`, `.alive`, `.owner`
- Owner-only `.mode public` and `.mode private`
- Group `.tagall`, `.hidetag`, `.kick`, `.promote`, `.demote`

## Important hosting note
The WhatsApp connection is a persistent Node.js process. Cloudflare Pages is suitable for the static pairing website, but Pages alone does not run this persistent Baileys process. Deploy this Node.js service on a persistent Node host with a persistent disk, and point your Cloudflare Pages site to its API. Cloudflare Workers/Pages Functions are not a drop-in host for a long-running Baileys socket.

## Run locally
1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env`.
3. Set `OWNER_NUMBER` to your WhatsApp number with country code, digits only (example format: `2348012345678`).
4. Run `npm install`.
5. Run `npm start`.
6. Open `http://localhost:3000/health`.

## Pairing API
Send JSON to `POST /api/pair`:
```json
{ "number": "2348012345678" }
```
The response contains the WhatsApp pairing code. Enter it in WhatsApp > Linked devices > Link a device > Link with phone number instead.

## Security
- Never commit `.env`, `auth_info/`, pairing codes, or WhatsApp credentials.
- Keep the repository private once setup is complete.
- Add authentication and rate limiting before exposing the pairing endpoint publicly.
- This starter does not yet include downloader/AI integrations; those require separately configured providers/APIs.
