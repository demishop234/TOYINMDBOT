require("dotenv").config();
const express = require("express");
const pino = require("pino");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys");
const { registerMessageHandler } = require("./lib/messages");

const app = express();
app.use(express.json());
app.use(express.static("public"));

const PORT = Number(process.env.PORT || 3000);
const AUTH_DIR = process.env.AUTH_DIR || "./auth_info";
let sock;
let latestPairingCode = null;
let connecting = false;

app.get("/health", (_req, res) => {
  res.json({ ok: true, bot: process.env.BOT_NAME || "TOYINMDBOT", connected: Boolean(sock?.user) });
});

// Pairing codes are sensitive. This endpoint is intentionally rate-limited
// in production deployments by your hosting provider/reverse proxy.
app.post("/api/pair", async (req, res) => {
  try {
    const number = String(req.body?.number || "").replace(/\D/g, "");
    if (number.length < 10 || number.length > 15) {
      return res.status(400).json({ error: "Enter a valid number with country code, digits only." });
    }
    if (sock?.user) return res.status(409).json({ error: "Bot is already connected." });
    if (connecting) return res.status(429).json({ error: "A pairing request is already being processed. Try again shortly." });

    connecting = true;
    const code = await startBot(number);
    latestPairingCode = code;
    return res.json({ code });
  } catch (err) {
    console.error("Pairing error:", err.message);
    return res.status(500).json({ error: "Could not create pairing code. Check server logs and try again." });
  } finally {
    connecting = false;
  }
});

async function startBot(phoneNumber) {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
  const { version } = await fetchLatestBaileysVersion();
  sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["TOYINMDBOT", "Chrome", "1.0.0"],
    markOnlineOnConnect: false
  });

  sock.ev.on("creds.update", saveCreds);
  registerMessageHandler(sock);

  if (!sock.authState.creds.registered) {
    await new Promise(resolve => setTimeout(resolve, 1500));
    return await sock.requestPairingCode(phoneNumber);
  }
  return "ALREADY_REGISTERED";
}

async function reconnect() {
  try {
    const { state, saveCreds } = await useMultiFileAuthState(AUTH_DIR);
    const { version } = await fetchLatestBaileysVersion();
    sock = makeWASocket({
      version, auth: state, logger: pino({ level: "silent" }),
      browser: ["TOYINMDBOT", "Chrome", "1.0.0"]
    });
    sock.ev.on("creds.update", saveCreds);
    registerMessageHandler(sock);
    sock.ev.on("connection.update", ({ connection, lastDisconnect }) => {
      if (connection === "close") {
        const status = lastDisconnect?.error?.output?.statusCode;
        if (status !== DisconnectReason.loggedOut) setTimeout(reconnect, 5000);
        else console.log("Logged out. Remove auth state and pair again.");
      }
      if (connection === "open") console.log("TOYINMDBOT connected.");
    });
  } catch (e) {
    console.error("Reconnect error:", e.message);
    setTimeout(reconnect, 10000);
  }
}

app.listen(PORT, () => {
  console.log(`TOYINMDBOT server listening on ${PORT}`);
  // Reuse an existing saved session when present.
  reconnect();
});
