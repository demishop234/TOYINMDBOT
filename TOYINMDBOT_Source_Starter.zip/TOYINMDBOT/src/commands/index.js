const { jidNormalizedUser } = require("@whiskeysockets/baileys");

const PREFIX = process.env.PREFIX || ".";
const BOT_NAME = process.env.BOT_NAME || "TOYINMDBOT";
let mode = (process.env.BOT_MODE || "public").toLowerCase();

const getText = m => {
  const x = m.message || {};
  return x.conversation || x.extendedTextMessage?.text ||
    x.imageMessage?.caption || x.videoMessage?.caption || "";
};
const senderOf = m => jidNormalizedUser(m.key.participant || m.key.remoteJid || "");
const ownerJid = () => (String(process.env.OWNER_NUMBER || "").replace(/\D/g, "") + "@s.whatsapp.net");

async function handleCommand(sock, msg) {
  const chat = msg.key.remoteJid;
  const sender = senderOf(msg);
  const text = getText(msg).trim();
  if (!text.startsWith(PREFIX)) return;
  const [raw, ...args] = text.slice(PREFIX.length).trim().split(/\s+/);
  const cmd = (raw || "").toLowerCase();
  const isOwner = Boolean(process.env.OWNER_NUMBER) && sender === ownerJid();

  if (mode === "private" && !isOwner) return;

  const reply = body => sock.sendMessage(chat, { text: body }, { quoted: msg });
  const metadata = chat.endsWith("@g.us") ? await sock.groupMetadata(chat).catch(() => null) : null;
  const participants = metadata?.participants || [];
  const botJid = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";
  const botIsAdmin = participants.some(p => p.id === botJid && (p.admin === "admin" || p.admin === "superadmin"));
  const senderIsAdmin = participants.some(p => p.id === sender && (p.admin === "admin" || p.admin === "superadmin"));
  const requireGroupAdmin = async () => {
    if (!metadata) { await reply("This command only works in groups."); return false; }
    if (!senderIsAdmin && !isOwner) { await reply("Only group admins can use this command."); return false; }
    if (!botIsAdmin) { await reply("Make TOYINMDBOT a group admin first."); return false; }
    return true;
  };

  switch (cmd) {
    case "menu":
    case "help":
      return reply(`╭───「 ${BOT_NAME} 」\n│ Prefix: ${PREFIX}\n│ Mode: ${mode}\n├── GENERAL\n│ ${PREFIX}menu\n│ ${PREFIX}ping\n│ ${PREFIX}alive\n├── GROUP (admin)\n│ ${PREFIX}kick @user\n│ ${PREFIX}promote @user\n│ ${PREFIX}demote @user\n│ ${PREFIX}tagall\n│ ${PREFIX}hidetag\n├── OWNER\n│ ${PREFIX}mode public/private\n╰────────────`);
    case "ping":
      return reply("Pong! 🏓 TOYINMDBOT is online.");
    case "alive":
      return reply("TOYINMDBOT is alive and running.");
    case "owner":
      return reply(`Bot owner: ${process.env.OWNER_NUMBER || "Not configured"}`);
    case "mode":
      if (!isOwner) return reply("Only the bot owner can change the mode.");
      if (!["public", "private"].includes((args[0] || "").toLowerCase())) return reply("Usage: .mode public OR .mode private");
      mode = args[0].toLowerCase();
      return reply(`Bot mode changed to ${mode}.`);
    case "tagall": {
      if (!(await requireGroupAdmin())) return;
      const mentions = participants.map(p => p.id);
      return sock.sendMessage(chat, { text: args.join(" ") || "Attention everyone!", mentions }, { quoted: msg });
    }
    case "hidetag": {
      if (!(await requireGroupAdmin())) return;
      return sock.sendMessage(chat, { text: args.join(" ") || " ", mentions: participants.map(p => p.id) }, { quoted: msg });
    }
    case "kick":
    case "promote":
    case "demote": {
      if (!(await requireGroupAdmin())) return;
      const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
      if (!mentioned.length) return reply(`Tag a member. Example: ${PREFIX}${cmd} @user`);
      const action = cmd === "kick" ? "remove" : cmd;
      await sock.groupParticipantsUpdate(chat, mentioned, action);
      return reply(`Done: ${cmd}.`);
    }
    default:
      return reply(`Unknown command: ${cmd}. Send ${PREFIX}menu.`);
  }
}
module.exports = { handleCommand };
